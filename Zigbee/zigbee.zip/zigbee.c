#include "zigbee.h"

volatile uint8_t zigbeeReceive[ZIGBEE_MESSAGE_LENTH];	//ʵʱ��¼�յ�����Ϣ
volatile uint8_t zigbeeMessage[ZIGBEE_MESSAGE_LENTH];//��������˳���õ�����Ϣ
volatile int message_index = 0;
volatile int message_head = -1;
uint8_t zigbeeBuffer[1];

UART_HandleTypeDef* zigbee_huart;


volatile struct BasicInfo Game;
volatile struct CarInfo Car[2];
volatile struct PassengerInfo Passenger[2];

/***********************�ӿ�****************************/
void zigbee_Init(UART_HandleTypeDef *huart)
{
	zigbee_huart = huart;
	HAL_UART_Receive_IT(zigbee_huart, zigbeeBuffer, 1);
}


void zigbeeMessageRecord(void)
{
	zigbeeMessage[message_index] = zigbeeBuffer[0];
	message_index = receiveIndexAdd(message_index, 1);

	if (zigbeeMessage[receiveIndexMinus(message_index, 2)] == 0x0D
		&& zigbeeMessage[receiveIndexMinus(message_index, 1)] == 0x0A)
	{
		if (receiveIndexMinus(message_index, message_head) == 0)
		{

			int index = message_head;
			for (int i = 0; i < 32; i++)
			{
				zigbeeReceive[i] = zigbeeMessage[index];
				index = receiveIndexAdd(index, 1);
			}
			DecodeAll();
		}
		else
		{
			message_head = message_index;
		}
	}
	HAL_UART_Receive_IT(zigbee_huart, zigbeeBuffer, 1);
}

enum GameStateEnum getGameState(void)
{
	uint8_t state = Game.GameState;
	if (state == 0)
	{
		return GameNotStart;
	}
	else if (state == 1)
	{
		return GameGoing;
	}
	else if (state == 2)
	{
		return GamePause;
	}
	else if (state == 3)
	{
		return GameOver;
	}

	return GameNotStart;
}

uint16_t getGameTime(void)
{
	return Game.Time;
}

uint16_t getPassengerNum(void)
{
	return Game.PassengerNum;
}

uint16_t getBall_X(void)
{
	return Game.BallPos.X;
}

uint16_t getBall_Y(void)
{
	return Game.BallPos.Y;
}


uint16_t getBallExistence(void)
{
	return Game.BallExist;	
}






uint16_t getCarInfo_X(int CarNo)
{
	if (CarNo != 0 && CarNo != 1)
		return (uint16_t)INVALID_ARG;
	else
		return Car[CarNo].pos.X;
}

uint16_t getCarInfo_Y(int CarNo)
{
	if (CarNo != 0 && CarNo != 1)
		return (uint16_t)INVALID_ARG;
	else
		return Car[CarNo].pos.Y;
}

struct Position getCarInfo_pos(int CarNo)
{
	return Car[CarNo].pos;
}


uint16_t getCarInfo_Score(int CarNo)
{
	if (CarNo != 0 && CarNo != 1)
		return (uint16_t)INVALID_ARG;
	else
		return (uint16_t)Car[CarNo].Score;
}

uint16_t getCarInfo_PickPsgNum(int CarNo)
{
	if (CarNo != 0 && CarNo != 1)
		return (uint16_t)INVALID_ARG;
	else
		return Car[CarNo].PickPsgNum;
}

uint16_t getCarInfo_GetBallNum(int CarNo)
{
	if (CarNo != 0 && CarNo != 1)
		return (uint16_t)INVALID_ARG;
	else
		return Car[CarNo].GetBallNum;
}

uint16_t getCarInfo_SendBallNum(int CarNo)
{
	if (CarNo != 0 && CarNo != 1)
		return (uint16_t)INVALID_ARG;
	else
		return Car[CarNo].SendBallNum;
}

enum CarArea getCarInfo_Area(int CarNo)
{

	if ((Car[CarNo].Area & 0x01) == 0)
	{
		return OnRoad;
	}
	else
	{
		return InMaze;
	}
}

enum CarTask getCarInfo_Task(int CarNo)
{
	if ((Car[CarNo].Task & 0x01) == 0)
	{
		return Rescue;
	}
	else
	{
		return Collect;
	}
}


//��ó˿�x��0��1�������Ϣ�����������ǰ�˿��������򷵻�INVALID_ARG
uint16_t getPassengerPos_X(uint8_t px)
{
	if (px >= getPassengerNum())
	{
		return (uint16_t)INVALID_ARG;
	}

	return Passenger[px].pos.X;
}

uint16_t getPassengerPos_Y(uint8_t px)
{
	if (px >= getPassengerNum())
	{
		return (uint16_t)INVALID_ARG;
	}

	return Passenger[px].pos.Y;
}

struct Position getPassengerPos(uint8_t px)
{
	return Passenger[px].pos;
}

/***************************************************/

void DecodeBasicInfo()
{
	Game.Time = (zigbeeReceive[0] << 8) + zigbeeReceive[1];
	Game.GameState = (zigbeeReceive[2] & 0xC0) >> 6;

	Game.BallPos.X = ((zigbeeReceive[3] & 0x08) << 5) + zigbeeReceive[12];
	Game.BallPos.Y = ((zigbeeReceive[3] & 0x04) << 6) + zigbeeReceive[13];
	Game.BallExist = (zigbeeReceive[3] & 0x02) >> 1;

	Game.PassengerNum = 2;

}

void DecodeCarAInfo()
{
	Car[0].No = 0;

	Car[0].Area = (zigbeeReceive[2] & 0x20) >> 5;
	Car[0].pos.X = ((zigbeeReceive[2] & 0x08) << 5) + zigbeeReceive[4];
	Car[0].pos.Y = ((zigbeeReceive[2] & 0x04) << 6) + zigbeeReceive[5];
	Car[0].Task = (zigbeeReceive[3] & 0x01);

	Car[0].Score = (zigbeeReceive[14] << 8) + zigbeeReceive[15];
	Car[0].PickPsgNum = zigbeeReceive[18];
	Car[0].GetBallNum = zigbeeReceive[20];
	Car[0].SendBallNum = zigbeeReceive[22];
}

void DecodeCarBInfo()
{
	Car[1].No = 1;

	Car[1].Area = (zigbeeReceive[2] & 0x10) >> 4;
	Car[1].pos.X = ((zigbeeReceive[2] & 0x02) << 7) + zigbeeReceive[6];
	Car[1].pos.Y = ((zigbeeReceive[2] & 0x01) << 8) + zigbeeReceive[7];
	Car[1].Task = (~zigbeeReceive[3]) & 0x01;


	Car[1].Score = (zigbeeReceive[16] << 8) + zigbeeReceive[17];
	Car[1].PickPsgNum = zigbeeReceive[19];
	Car[1].GetBallNum = zigbeeReceive[21];
	Car[1].SendBallNum = zigbeeReceive[23];
}

void DecodePassenger0()
{
	Passenger[0].No = 0;
	Passenger[0].pos.X = ((zigbeeReceive[3] & 0x80) << 1) + zigbeeReceive[8];
	Passenger[0].pos.Y = ((zigbeeReceive[3] & 0x40) << 2) + zigbeeReceive[9];
}

void DecodePassenger1()
{
	Passenger[1].No = 1;
	Passenger[1].pos.X = ((zigbeeReceive[3] & 0x20) << 3) + zigbeeReceive[10];
	Passenger[1].pos.Y = ((zigbeeReceive[3] & 0x10) << 4) + zigbeeReceive[11];
}


void DecodeAll()
{
	DecodeBasicInfo();
	DecodeCarAInfo();
	DecodeCarBInfo();
	DecodePassenger0();
	DecodePassenger1();
}


int receiveIndexMinus(int index_h, int num)
{
	if (index_h - num >= 0)
	{
		return index_h - num;
	}
	else
	{
		return index_h - num + ZIGBEE_MESSAGE_LENTH;
	}
}

int receiveIndexAdd(int index_h, int num)
{
	if (index_h + num < ZIGBEE_MESSAGE_LENTH)
	{
		return index_h + num;
	}
	else
	{
		return index_h + num - ZIGBEE_MESSAGE_LENTH;
	}
}
